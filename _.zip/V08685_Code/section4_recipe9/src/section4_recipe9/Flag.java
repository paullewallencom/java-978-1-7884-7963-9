package section4_recipe9;

public class Flag {
	
	public boolean flag=true;

}
