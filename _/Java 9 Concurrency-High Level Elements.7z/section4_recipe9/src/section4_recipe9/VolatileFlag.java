package section4_recipe9;

public class VolatileFlag {
	
	public volatile boolean flag=true;

}
